export default function ConnectComponent() {
  return (
    <div className="z-[1] h-full flex flex-col align-middle justify-center w-full">
      <h1
        className="text-[32px] font-bold text-white text-center"
      >
        Please connect the Wallet
      </h1>
    </div>
  );
}