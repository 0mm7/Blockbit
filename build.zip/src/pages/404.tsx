export default function Home() {
  return (
    <div className="z-[1] h-full flex flex-col align-middle justify-center w-full">
      <h1
        className="text-lg font-bold text-white uppercase text-center"
      >
        404 | Not Found
      </h1>
    </div>
  );
};
